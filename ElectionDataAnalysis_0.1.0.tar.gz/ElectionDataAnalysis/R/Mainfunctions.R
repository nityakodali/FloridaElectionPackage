
#Factor Analysis of Florida Election Data


#This first section explores the importing and setup of the data.
#Here, I am going to set up some summary stat code
#first 2 are pie chats as described:
#One function will be for individual county in a certain year stats
#another function will be total year stats





