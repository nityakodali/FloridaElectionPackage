#' Setup Function
#'
#' @return nothing, but prints out directions on what to do.
#' @export
#'
#' @examples setup()
setup<-function(){
  print("download fullVRreport.xlsx into your working directory and copy the filepath of fullVRreport.xlsx. insert the directory in quotes as the argument for clean_and_set_data function.")
}
