This repository is dedicated to a file package that analyzes election data in the state of florida and returns grpahics usable for research purposes.
This package also contains a function that uses linear models to predict the 2024 election results for the state of Florida.
This package uses the namespace ElectionDataAnalysis::
To use the package once downloaded, please run the setup() function and follow the corresponding instructions. 
Please note that Roxygen was used to provide help when using the function. Any doubts can be checked with the help function built in with roxygen skeleton (the ? function).
